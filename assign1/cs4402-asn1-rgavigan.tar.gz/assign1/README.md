### Running Problem 1
```sh
make inverseMatrix && make testInverse
```

### Running Problem 2
```sh
make closestPairs && make testClosest
```